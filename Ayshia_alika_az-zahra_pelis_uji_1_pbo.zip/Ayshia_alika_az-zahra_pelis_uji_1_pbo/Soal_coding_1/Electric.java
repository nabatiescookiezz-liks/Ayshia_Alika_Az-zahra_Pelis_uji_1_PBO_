/**
 * Interface Electric — mendefinisikan kontrak kendaraan listrik.
 * Class apapun yang implement ini WAJIB punya method chargeBattery().
 */
public interface Electric {

    // Method abstract dari interface
    void chargeBattery();

    // Default method — fitur tambahan opsional (Java 8+)
    default void cekStatus() {
        System.out.println("[Electric] Memeriksa status baterai...");
    }
}